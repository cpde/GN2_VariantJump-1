<?php

/**
 * Module information
 */

 $aModule = array(
    'id'            => 'gn2netwerk',
    'title'         => 'gn2 :: VariantJump',
    'description'   => '',
    'thumbnail'     => 'gn2.jpg',
    'version'       => '0.1',
    'author'        => 'gn2 netwerk',
    'extend'        => array(
        'oxwarticledetails' => 'gn2netwerk/gn2_variantjump/gn2_variantjump_oxwarticledetails',
        'oxarticle'         => 'gn2netwerk/gn2_variantjump/gn2_variantjump_oxarticle',
    )
);
