
# Settings

Settings can be found in [gn2_variantjump.ini]

## Custom Functions

If you need something special for your project:
Add *multiple functions* with your own rules to which variant should be redirected.
Take a look at the example [mySpecialFunction.php]